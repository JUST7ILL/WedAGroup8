# Sample Code for NTU Car Car Course Midterm Project

## Installation

### Conda

Installation guide for conda can be found [here](https://conda.io/projects/conda/en/latest/user-guide/install/index.html).

```bash
conda create -n car python=3.12
conda activate car
cd python
pip install -r requirements.txt
```

### Pip

```bash
cd python
pip install -r requirements.txt
```
